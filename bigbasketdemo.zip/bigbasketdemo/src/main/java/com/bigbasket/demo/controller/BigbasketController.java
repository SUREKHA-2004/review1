package com.bigbasket.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bigbasket.demo.model.Bigbasket;
import com.bigbasket.demo.service.BigbasketService;

@RestController
public class BigbasketController {
	@Autowired
	BigbasketService bigbasketService;
	
	@GetMapping(value = "/fetchBigbaskets")
	public List<Bigbasket>getAllBigbaskets()
	{
		List<Bigbasket> bigbasketList = bigbasketService.getAllBigbaskets();
		return bigbasketList;
	}
	@PostMapping(value="/saveBig")
	public Bigbasket saveBigbasket(@RequestBody Bigbasket s)
	{
		return bigbasketService.saveBigbasket(s);
	}
	@PutMapping(value="/updateBigbasket")
	public Bigbasket updateBigbasket(@RequestBody Bigbasket s)
	{
		return bigbasketService.saveBigbasket(s);
	}
	@DeleteMapping("/deleteBigbasket/{id}")
	public void deleteBigbasket(@PathVariable("id")int id)
	{
		bigbasketService.deleteBigbasket(id);
	}
	@GetMapping(value="/getBigbasket/{id}")
	public Bigbasket getBigBasket(@PathVariable("id")int id)
	{
		return bigbasketService.getBigBasket(id);
	}
}
