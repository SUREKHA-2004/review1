package com.bigbasket.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bigbasket.demo.model.Bigbasket;
@Repository
public interface BigbasketRepository extends JpaRepository<Bigbasket, Integer> {

}
