package com.bigbasket.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BigbasketdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BigbasketdemoApplication.class, args);
	}

}
