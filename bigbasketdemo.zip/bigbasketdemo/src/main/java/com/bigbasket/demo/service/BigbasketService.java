package com.bigbasket.demo.service;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bigbasket.demo.model.Bigbasket;
import com.bigbasket.demo.repository.BigbasketRepository;


@Service

public class BigbasketService {
     @Autowired 
     BigbasketRepository bigbasketRepository;
    public List<Bigbasket> getAllBigbaskets()
    {
    	List<Bigbasket>bigbasketList=bigbasketRepository.findAll();
    	return bigbasketList;
     }
    public Bigbasket saveBigbasket(Bigbasket s)
    {
    	Bigbasket obj=bigbasketRepository.save(s);
    	return obj;
}
public Bigbasket updateBigbasket(Bigbasket s)
{
	Bigbasket obj1=bigbasketRepository.save(s);
	return obj1;
}
public void deleteBigbasket(int id)
{
    bigbasketRepository.deleteById(id);
}
public Bigbasket getBigBasket(int id )
{
	Bigbasket s = bigbasketRepository.findById(id).get();
	return s;
}
}


